licznik = 10

while licznik > 0:
    print('Stan licznika:', licznik)
    licznik = licznik - 1
print('Start!')